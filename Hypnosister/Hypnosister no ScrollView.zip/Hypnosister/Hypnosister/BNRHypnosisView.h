//
//  BNRHypnosisView.h
//  Hypnosister
//
//  Created by Hyon Sim on 4/22/15.
//  Copyright (c) 2015 bWERX. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BNRHypnosisView : UIView

@end
